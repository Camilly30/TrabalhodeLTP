
let json = "https://www.luizpicolo.com.br/api.json"
let XHR = new XMLHttpRequest();
XHR.open("GET", json);
XHR.responseType = "json";
XHR.send();


XHR.onload = function() {
	let noticias = XHR.response;

	class Noticias {
		constructor(title, description, author, publishedAt, urlToImage ,url) {
			this.titulo = title;
			this.description = description;
			this.author = author;
			this.publishedAt = publishedAt;
			this.urlToImage = urlToImage;
			this.url = url;
		}
		mostrar_titulo() {
		   return `<div class="pablo"> 
<div class="cachorro"> 
    <h1> <a href="${this.url}">${this.titulo}</a></h1>
        <h2>${this.description}</h2>
        <h3>${this.author}</h3>
        <h4>${this.publishedAt}</h4>
</div>
</div>`
		}
	}
	class DestaQ extends Noticias {
		constructor(title, description, author, publishedAt, urlToImage,url) {
			super(title, description, author, publishedAt, urlToImage,url)
		}
		mostrarNoticia() {
			return `<center><img  src="${this.urlToImage}"/></center> `         
		}
	}

	const destaquezinho = document.getElementById('destaque');
	let destaque1 = new DestaQ(
	 noticias.articles[0].title,
		noticias.articles[0].description,
		noticias.articles[0].author,
		noticias.articles[0].publishedAt,
		noticias.articles[0].urlToImage
	)
	destaquezinho.insertAdjacentHTML('afterbegin', destaque1.mostrarNoticia());

	const elemento = document.getElementById('list');
	noticias.articles.forEach(noticias => {
		let titulo1 = new Noticias(noticias.title, noticias.description, noticias.author, noticias.publishedAt, noticias.urlToImage, noticias.url);
		elemento.insertAdjacentHTML('beforeend', titulo1.mostrar_titulo());
	})
};



